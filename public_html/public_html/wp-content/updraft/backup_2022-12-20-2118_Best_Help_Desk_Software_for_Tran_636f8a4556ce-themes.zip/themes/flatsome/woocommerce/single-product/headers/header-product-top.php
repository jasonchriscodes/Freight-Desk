<div class="page-title shop-page-title product-page-title">
	<div class="page-title-inner flex-row medium-flex-wrap container">
	  <div class="flex-col flex-grow medium-text-center">
	  		<?php do_action('flatsome_product_title') ;?>
	  </div><!-- .flex-left -->
	  
	   <div class="flex-col medium-text-center">
		   	<?php do_action('flatsome_product_title_tools') ;?>
	   </div><!-- .flex-right -->
	</div><!-- flex-row -->
</div><!-- .page-title -->
